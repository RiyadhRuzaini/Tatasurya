let teksturMatahari;
let teksturBumi;
let teksturBulan;
let teksturMercury;
let teksturVenus;
let teksturPluto;
let teksturMars;
let teksturSaturn;
let teksturJupiter;
let teksturNeptune;
let teksturUranus;
let teskturCincin;

function preload() {
  teksturMatahari = loadImage('sun.jpg');
  teksturBumi = loadImage('earth.jpg');
  teksturBulan = loadImage('moon.jpg');
  teksturMercury = loadImage('mercury.jpg');
  teksturMars = loadImage('mars.jpg');
  teksturVenus = loadImage('venus.jpg');
  teksturPluto = loadImage('pluto.jpg');
  teksturSaturn = loadImage('saturn.jpg');
  teksturJupiter = loadImage('jupiter.jpg');
  teksturNeptune = loadImage('neptunemap.jpg');
  teksturUranus = loadImage('uranus.jpg');
  teskturCincin = loadImage('saturnringcolor.jpg');
  
}

function setup() {
  createCanvas(1000, 800, WEBGL);
}

function draw() {
  background(0);

  push();
  camera(0, -1050, 2290, 0, 0, 0, 0, 1, 0);
  noFill();
  stroke(255);
  rotateX(radians(90));
  ellipse(0, 0, 550, 550);
  ellipse(0, -0, 850, 850);
  ellipse(0, -0, 1050, 1050);
  ellipse(0, -0, 1250, 1250);
  ellipse(0, -0, 1550, 1550);
  ellipse(0, -0, 1850, 1850);
  ellipse(0, -0, 2150, 2150);
  ellipse(0, -0, 2450, 2450);
  ellipse(0, -0, 2750, 2750);
  pop();
  
  
  
  // Matahari
  camera(0, -1050, 2290, 0, 0, 0, 0, 1, 0);
  rotateY(millis() * 0.001 * radians(10));
  noStroke();
  texture(teksturMatahari);
  sphere(100);

  // Mercury
  pointLight(250, 250, 250, -100, -100, 0);
  camera(0, -1050, 2290, 0, 0, 0, 0, 1, 0);
  rotateY(millis() * 0.001 * radians(90));
  translate(-280, -0);
  noStroke();
  texture(teksturMercury);
  sphere(28);

  // Venus
  pointLight(250, 250, 250, -100, -100, 0);
  camera(0, -1050, 2290, 0, 0, 0, 0, 1, 0);
  rotateY(millis() * 0.001 * radians(-45));
  translate(-420, -0);
  noStroke();
  texture(teksturVenus);
  sphere(40);

  // Bumi
  pointLight(250, 250, 250, -100, -100, 0);
  camera(0, -1050, 2290, 0, 0, 0, 0, 1, 0);
  rotateY(millis() * 0.001 * radians(30));
  translate(-530, -0);
  texture(teksturBumi);
  sphere(45);
  
  // Bulan
  rotateY(millis() * 0.001 * radians(90));
  translate(75, -0);
  texture(teksturBulan);
  sphere(15);

  // Mars
  pointLight(250, 250, 250, -100, -100, 0);
  camera(0, -1050, 2290, 0, 0, 0, 0, 1, 0);
  rotateY(millis() * 0.001 * radians(60));
  translate(-630, -0);
  noStroke();
  texture(teksturMars);
  sphere(30);

  // Jupiter
  pointLight(250, 250, 250, -100, -100, 0);
  camera(0, -1050, 2290, 0, 0, 0, 0, 1, 0);
  rotateY(millis() * 0.001 * radians(20));
  translate(-768, -0);
  noStroke();
  texture(teksturJupiter);
  sphere(66);

  // Cincin Saturn
  push();
  rotateX(radians(-90));
  texture(teskturCincin);
  torus(85, 15, 65, 65);
  pop();
  // Saturn
  pointLight(250, 250, 250, -100, -100, 0);
  camera(0, -1050, 2290, 0, 0, 0, 0, 1, 0);
  rotateY(millis() * 0.001 * radians(-30));
  translate(-920, -0);
  noStroke();
  texture(teksturSaturn);
  sphere(59);

  // Uranus
  pointLight(250, 250, 250, -100, -100, 0);
  camera(0, -1050, 2290, 0, 0, 0, 0, 1, 0);
  rotateY(millis() * 0.001 * radians(30));
  translate(-1080, -0);
  noStroke();
  texture(teksturUranus);
  sphere(50);
  
  // Neptune
  pointLight(250, 250, 250, -100, -100, 0);
  camera(0, -1050, 2290, 0, 0, 0, 0, 1, 0);
  rotateY(millis() * 0.001 * radians(-45));
  translate(-1220, -0);
  noStroke();
  texture(teksturNeptune);
  sphere(49);
  
  // Pluto
  pointLight(250, 250, 250, -100, -100, 0);
  camera(0, -1050, 2290, 0, 0, 0, 0, 1, 0);
  rotateY(millis() * 0.001 * radians(60));
  translate(-1375, -0);
  noStroke();
  texture(teksturPluto);
  sphere(20);
  

}